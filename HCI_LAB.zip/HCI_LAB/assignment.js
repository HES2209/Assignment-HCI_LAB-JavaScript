//Number 1
var count = 11;
while (count<= 40){
    console.log(count);
        count += 2;
}

for(var counts =11; counts<=40;){
    console.log(counts);
        counts+=2;
}

//Number 2
const nums = [1,2,3,4,5]
nums.reverse();
console.log(nums);

const alphabet = ["a","b","c","d"]
alphabet.reverse();
console.log(alphabet);

//Number 3
const movies = [
    {
        title : "In Bruges",
        rating : "5 stars",
        hasWatched : true,
    },
    {
        title : "Frozen",
        rating : "4.5 stars",
        hasWatched : false,
    },
    {
        title : "Mad Max Furry Road",
        rating : "5 stars",
        hasWatched : true,
    },
    {
        title : "Les Miserables",
        rating : "3.5 stars",
        hasWatched : false,
    }
]
console.log(movies)

//Number 4
function isUniform(arr) {
    if (arr.length === 0) return true;

    const firstElement = arr[0];

    for (let i = 1; i < arr.length; i++) {
        if (arr[i] !== firstElement) {
            return false;
        }
    }
    return true;
}
console.log(isUniform([1, 1, 1, 1])); // true
console.log(isUniform([1, 2, 1, 1])); // false
console.log(isUniform(['a', 'a', 'a'])); // true
console.log(isUniform(['a', 'b', 'a'])); // false
console.log(isUniform([])); // true

//Number 5
function sumArray(arra) {
    let sum = 0;
    for (let i = 0; i < arra.length; i++) {
        sum += arra[i];
    }
    return sum;
}

console.log(sumArray([1, 2, 3])); // 6
console.log(sumArray([10, 3, 10,4])); // 27

//Number 6
function palindrom(str){
    let reversedStr = str.split('').reverse().join('');
    if (str ===reversedStr){ 
        return true
} else {
        return false      
}
}

console.log(palindrom("racecar")); // true
console.log(palindrom("hello")); //false